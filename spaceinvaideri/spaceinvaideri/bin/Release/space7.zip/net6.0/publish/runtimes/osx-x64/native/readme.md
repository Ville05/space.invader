file needs to be called `libraylib.dylib` for mac

see `sub-modules/readme.md` for build details