file needs to be called `libraylib.so` for linux

see `sub-modules/readme.md` for build details