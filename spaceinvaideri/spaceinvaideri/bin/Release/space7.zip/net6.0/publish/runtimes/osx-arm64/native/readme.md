files needs to be called these ways for mac arm64 (m1)

see `sub-modules/readme.md` for build details
